$(function() {
  const $gallery = $(".gallery a").simpleLightbox();
});
